import csv
import random
from flask import Blueprint, render_template, request
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.neighbors import NearestNeighbors
import numpy

main_bp = Blueprint('main', __name__)


@main_bp.route('/', methods=['GET'])
def index():
    return render_template('index.html'), 200 

@main_bp.route('/recommendation', methods=['GET','POST'])
def tmp():
    all_data = request.form
    if request.method == 'POST':
        areacode = all_data.get("areaCode")
        tag_list = all_data.getlist('tag')
        df = pd.read_csv("fffffffinal_data.csv", index_col = 0)
        cv = CountVectorizer()
        cat = cv.fit_transform(df.cat1)
        cat1=pd.DataFrame(
            cat.toarray(),
            columns=list(sorted(cv.vocabulary_.keys(), key=lambda x : cv.vocabulary_[x]))
            )
        cat1 = cat1.T
        
        nbrs = NearestNeighbors(n_neighbors = 3).fit(cat1)

        if len(tag_list) == 1: #1개 선택했을 때
            a = cat1.loc[tag_list[0]]
            distances, indexes = nbrs.kneighbors([a])
            df = df.loc[df['addr_area'] == areacode, :]
            recommendations = df.iloc[indexes.tolist()[0]]

        if len(tag_list) == 2: #2개 선택했을 때
            a = cat1.loc[tag_list[0]]
            b = cat1.loc[tag_list[1]]
            val = a + b
            distances, indexes = nbrs.kneighbors([val])
            df = df.loc[df['addr_area'] == areacode, :]
            recommendations = df.iloc[indexes.tolist()[0]]
        
        if len(tag_list) == 3: #3개 선택했을 때
            a = cat1.loc[tag_list[0]]
            b = cat1.loc[tag_list[1]]
            c = cat1.loc[tag_list[2]]
            val = a + b + c
            distances, indexes = nbrs.kneighbors([val])
            df = df.loc[df['addr_area'] == areacode, :]
            recommendations = df.iloc[indexes.tolist()[0]]
            
        recommendations = recommendations[["title", "firstimage", "firstimage2"]]
        recommendations["distance"] = distances[0]

        return render_template('recommendation.html', value = recommendations), 200